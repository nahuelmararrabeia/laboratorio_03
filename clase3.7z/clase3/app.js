window.addEventListener("load", agregarManejadores);

function agregarManejadores() {
  document.getElementById("btnGuardar").addEventListener("click", guardar);
}

function guardar() {
  var inputNombre = document.getElementById("inputNombre");
  var inputApellido = document.getElementById("inputApellido");
  var nombre = inputNombre.value;
  var apellido = inputApellido.value;
  if (nombre == "" || apellido == "") {
    if (nombre == "") inputNombre.className += " error";
    if (apellido == "") inputApellido.className += " error";
  } else {
    inputNombre.className += " sinError";
    inputApellido.className += " sinError";
    agregarATabla(nombre, apellido);
    inputNombre.value = "";
    inputApellido.value = "";
  }
}

function agregarATabla(nombre, apellido) {
  document.getElementById("bodyTable").innerHTML +=
    "<tr><td>" +
    nombre +
    "</td><td>" +
    apellido +
    '</td><td><a href="" onclick="borrar(event)">borrar</a></td></tr>';
}

function borrar(e)
{
    e.preventDefault();
    e.target.parentNode.parentNode.remove();
}
