window.addEventListener("load", cargar);

function cargar()
{
    document.getElementById("btnSumar").addEventListener("click", sumar);
    document.getElementById("btnSyG").addEventListener("click", sumarYGuardar);
}

function sumar()
{
    var nro1 = parseInt(document.getElementById("txtNro1").value);
    var nro2 = parseInt(document.getElementById("txtNro2").value);
    var suma = nro1 + nro2;
    document.getElementById("txtRtado").value = suma;
    return {"nro1": nro1, "nro2": nro2, "rtado": suma};
}

function sumarYGuardar()
{
    var obj = sumar();
    document.getElementById("tableBody").innerHTML += "<tr><td>" + obj.nro1 + "</td><td>" + obj.nro2 + "</td><td>" + obj.rtado + "</td></tr>";


}