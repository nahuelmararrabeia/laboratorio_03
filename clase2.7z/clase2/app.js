/*window.onload(function(){
    document.getElementById("btn").addEventListener("");
});*/

function cargar() {
    var boton = document.getElementById("btn");
    console.log("cargar");
    boton.addEventListener("click", log);
}

window.addEventListener("load", cargar);

function log() {
    var txtUsr = document.getElementById("txtUsr");
    alert(txtUsr.value);
}

